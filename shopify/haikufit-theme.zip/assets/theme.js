(() => {
  'use strict';

  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
  const strings = (window.theme && window.theme.strings) || {};

  /* ------------------------------------------------------------------------
   * Money formatting (mirrors Shopify's money filters)
   * ---------------------------------------------------------------------- */
  function formatMoney(cents, format) {
    if (typeof cents === 'string') cents = cents.replace('.', '');
    const placeholder = /\{\{\s*(\w+)\s*\}\}/;
    const fmt = format || '₹{{amount}}';

    const withDelimiters = (number, precision, thousands = ',', decimal = '.') => {
      if (isNaN(number) || number == null) return '0';
      const fixed = (number / 100).toFixed(precision);
      const [whole, frac] = fixed.split('.');
      const wholeFmt = whole.replace(/(\d)(?=(\d\d\d)+(?!\d))/g, `$1${thousands}`);
      return frac ? wholeFmt + decimal + frac : wholeFmt;
    };

    const match = fmt.match(placeholder);
    let value = '';
    switch (match ? match[1] : 'amount') {
      case 'amount_no_decimals': value = withDelimiters(cents, 0); break;
      case 'amount_with_comma_separator': value = withDelimiters(cents, 2, '.', ','); break;
      case 'amount_no_decimals_with_comma_separator': value = withDelimiters(cents, 0, '.', ','); break;
      case 'amount_with_space_separator': value = withDelimiters(cents, 2, ' ', ','); break;
      default: value = withDelimiters(cents, 2);
    }
    return fmt.replace(placeholder, value);
  }

  /* ------------------------------------------------------------------------
   * Announcement bar rotator
   * ---------------------------------------------------------------------- */
  $$('[data-announcement-rotator]').forEach((bar) => {
    const messages = $$('.announcement-bar__message', bar);
    if (messages.length < 2) return;
    let index = 0;
    const speed = (parseInt(bar.dataset.speed, 10) || 4) * 1000;
    setInterval(() => {
      messages[index].classList.remove('is-active');
      index = (index + 1) % messages.length;
      messages[index].classList.add('is-active');
    }, speed);
  });

  /* ------------------------------------------------------------------------
   * Header: drawer / search panels
   * ---------------------------------------------------------------------- */
  const setHeaderBottom = () => {
    const header = $('[data-header]');
    if (!header) return;
    const bottom = Math.max(header.getBoundingClientRect().bottom, 0);
    document.documentElement.style.setProperty('--header-bottom', `${bottom}px`);
  };
  setHeaderBottom();
  window.addEventListener('resize', setHeaderBottom);
  window.addEventListener('scroll', setHeaderBottom, { passive: true });

  const headerPanels = $$('[data-drawer], [data-search]');
  headerPanels.forEach((panel) => {
    panel.addEventListener('toggle', () => {
      if (!panel.open) {
        if (panel.matches('[data-drawer]')) document.body.style.overflow = '';
        return;
      }
      setHeaderBottom();
      headerPanels.forEach((other) => { if (other !== panel) other.open = false; });
      if (panel.matches('[data-drawer]')) document.body.style.overflow = 'hidden';
      if (panel.matches('[data-search]')) {
        const input = $('input[type="search"]', panel);
        if (input) setTimeout(() => input.focus(), 50);
      }
    });
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') headerPanels.forEach((p) => { p.open = false; });
  });

  /* ------------------------------------------------------------------------
   * Slideshow
   * ---------------------------------------------------------------------- */
  $$('[data-slideshow]').forEach((slideshow) => {
    const track = $('[data-slideshow-track]', slideshow);
    const slides = $$('.slideshow__slide', slideshow);
    const dots = $$('[data-slide-to]', slideshow);
    if (slides.length < 2) return;

    let current = 0;
    const goTo = (i) => {
      current = (i + slides.length) % slides.length;
      track.scrollTo({ left: track.clientWidth * current, behavior: 'smooth' });
    };

    track.addEventListener('scroll', () => {
      const i = Math.round(track.scrollLeft / track.clientWidth);
      if (i !== current) current = i;
      dots.forEach((d, n) => d.classList.toggle('is-active', n === i));
    }, { passive: true });

    dots.forEach((dot) => dot.addEventListener('click', () => goTo(parseInt(dot.dataset.slideTo, 10))));

    if (slideshow.dataset.autoplay === 'true' && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      const speed = (parseInt(slideshow.dataset.speed, 10) || 5) * 1000;
      let timer = setInterval(() => goTo(current + 1), speed);
      const pause = () => clearInterval(timer);
      const resume = () => { clearInterval(timer); timer = setInterval(() => goTo(current + 1), speed); };
      slideshow.addEventListener('mouseenter', pause);
      slideshow.addEventListener('mouseleave', resume);
      slideshow.addEventListener('touchstart', pause, { passive: true });
      slideshow.addEventListener('focusin', pause);
    }
  });

  /* ------------------------------------------------------------------------
   * Quantity buttons (product page + cart)
   * ---------------------------------------------------------------------- */
  document.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-qty-minus], [data-qty-plus]');
    if (!btn) return;
    const input = $('input', btn.closest('[data-quantity]'));
    const min = parseInt(input.min, 10) || 0;
    const value = parseInt(input.value, 10) || 0;
    input.value = btn.hasAttribute('data-qty-plus') ? value + 1 : Math.max(min, value - 1);
    input.dispatchEvent(new Event('change', { bubbles: true }));
  });

  /* Cart page: submit the form when a quantity changes */
  const cartForm = $('#CartForm');
  if (cartForm) {
    let timer;
    cartForm.addEventListener('change', (e) => {
      if (!e.target.matches('[data-cart-quantity]')) return;
      clearTimeout(timer);
      timer = setTimeout(() => cartForm.submit(), 500);
    });

    /* Save the order note as it's typed: one-click checkout buttons skip the form submit */
    const note = $('textarea[name="note"]', cartForm);
    if (note) {
      let noteTimer;
      const saveNote = () => {
        clearTimeout(noteTimer);
        fetch(`${window.theme.routes.cart}/update.js`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
          body: JSON.stringify({ note: note.value })
        }).catch(() => {});
      };
      note.addEventListener('input', () => { clearTimeout(noteTimer); noteTimer = setTimeout(saveNote, 400); });
      note.addEventListener('change', saveNote);
    }
  }

  /* ------------------------------------------------------------------------
   * Dialogs (size chart)
   * ---------------------------------------------------------------------- */
  document.addEventListener('click', (e) => {
    const opener = e.target.closest('[data-dialog-open]');
    if (opener) {
      const dialog = document.getElementById(opener.dataset.dialogOpen);
      if (dialog && dialog.showModal) dialog.showModal();
      return;
    }
    const closer = e.target.closest('[data-dialog-close]');
    if (closer) closer.closest('dialog').close();
    if (e.target.tagName === 'DIALOG') e.target.close();
  });

  /* ------------------------------------------------------------------------
   * Product: variant picker, gallery and media filtering
   * ---------------------------------------------------------------------- */
  $$('[data-product]').forEach((section) => {
    const variantsJson = $('[data-variants-json]', section);
    const form = $('[data-product-form]', section);
    const gallery = $('[data-gallery]', section);
    const mediaItems = gallery ? $$('[data-media-id]', gallery) : [];
    const mediaList = gallery ? $('.product__media-list', gallery) : null;
    const colorIndex = section.dataset.colorIndex === '' ? -1 : parseInt(section.dataset.colorIndex, 10);
    const filterMedia = section.dataset.filterMedia === 'true';
    const moneyFormat = section.dataset.moneyFormat;

    /* Gallery counter on mobile */
    const indexEl = gallery && $('[data-gallery-index]', gallery);
    const totalEl = gallery && $('[data-gallery-total]', gallery);
    const visibleMedia = () => mediaItems.filter((m) => !m.hidden);
    if (mediaList && indexEl) {
      mediaList.addEventListener('scroll', () => {
        const i = Math.round(mediaList.scrollLeft / mediaList.clientWidth) + 1;
        indexEl.textContent = Math.min(i, visibleMedia().length);
      }, { passive: true });
    }

    const filterMediaByColor = (color) => {
      if (!filterMedia || !color || !mediaItems.length) return;
      const key = color.toLowerCase().trim();
      const matches = mediaItems.filter((m) => m.dataset.mediaAlt === key);
      if (!matches.length) {
        mediaItems.forEach((m) => { m.hidden = false; });
      } else {
        mediaItems.forEach((m) => { m.hidden = !matches.includes(m); });
      }
      if (totalEl) totalEl.textContent = visibleMedia().length;
      if (indexEl) indexEl.textContent = 1;
      if (mediaList) mediaList.scrollLeft = 0;
    };

    if (!variantsJson || !form) {
      initProductForm(form);
      return;
    }

    const variants = JSON.parse(variantsJson.textContent);
    const fieldsets = $$('[data-option-index]', section);
    const idInput = $('[data-variant-id]', form);
    const addButton = $('[data-add-to-cart]', section);
    const addText = $('[data-add-to-cart-text]', section);
    const priceWrapper = $('[data-price-wrapper]', section);

    const selectedOptions = () => fieldsets.map((fs) => {
      const checked = $('input:checked', fs);
      return checked ? checked.value : null;
    });

    const updateAvailability = (selected) => {
      fieldsets.forEach((fs, optIndex) => {
        $$('input', fs).forEach((input) => {
          const available = variants.some((v) =>
            v.available &&
            v.options[optIndex] === input.value &&
            v.options.every((val, i) => i === optIndex || val === selected[i])
          );
          input.classList.toggle('is-unavailable', !available);
        });
      });
    };

    const renderPrice = (variant) => {
      if (!priceWrapper) return;
      const price = $('[data-price]', priceWrapper);
      if (!price) return;
      const onSale = variant.compare_at_price && variant.compare_at_price > variant.price;
      let html = `<span class="price__current">${formatMoney(variant.price, moneyFormat)}</span>`;
      if (onSale) {
        const pct = Math.round(((variant.compare_at_price - variant.price) * 100) / variant.compare_at_price);
        html += `<s class="price__compare">${formatMoney(variant.compare_at_price, moneyFormat)}</s>`;
        html += `<span class="price__discount">${(strings.discount || '__PERCENT__% OFF').replace('__PERCENT__', pct)}</span>`;
      }
      price.innerHTML = html;
      price.classList.toggle('price--on-sale', !!onSale);
    };

    // garment measurements for the chosen size, shown under the size buttons
    const measureEl = $('[data-size-measure]', section);
    let measures = {};
    try { measures = JSON.parse(($('[data-size-measures]', section) || {}).textContent || '{}'); } catch (_) { measures = {}; }
    const renderMeasure = () => {
      if (!measureEl) return;
      const fs = measureEl.closest('[data-option-index]');
      const checked = fs && $('input:checked', fs);
      const text = checked && measures[checked.value];
      measureEl.textContent = text ? `${checked.value}: ${text}` : '';
      measureEl.hidden = !text;
    };
    renderMeasure();

    const onChange = () => {
      const selected = selectedOptions();
      fieldsets.forEach((fs, i) => {
        const label = $('[data-option-value]', fs);
        if (label) label.textContent = selected[i] || '';
      });
      renderMeasure();
      updateAvailability(selected);

      const variant = variants.find((v) => v.options.every((val, i) => val === selected[i]));

      if (colorIndex >= 0) filterMediaByColor(selected[colorIndex]);

      if (!variant) {
        if (addButton) addButton.disabled = true;
        if (addText) addText.textContent = strings.unavailable;
        return;
      }

      idInput.value = variant.id;
      renderPrice(variant);
      updateExtras(variant);
      if (addButton) addButton.disabled = !variant.available;
      if (addText) addText.textContent = variant.available ? strings.addToCart : strings.soldOut;

      if (variant.featured_media && !(filterMedia && colorIndex >= 0)) {
        const target = mediaItems.find((m) => m.dataset.mediaId === String(variant.featured_media.id));
        if (target && mediaList) {
          if (window.matchMedia('(min-width: 990px)').matches) {
            mediaList.prepend(target);
          } else {
            mediaList.scrollTo({ left: target.offsetLeft, behavior: 'smooth' });
          }
        }
      }

      if (section.dataset.url) {
        const url = new URL(window.location.href);
        url.searchParams.set('variant', variant.id);
        window.history.replaceState({}, '', url.toString());
      }
    };

    /* Savings line, low stock, bundle tier prices and sticky bar */
    const stockJson = $('[data-stock-json]', section);
    const stock = stockJson ? JSON.parse(stockJson.textContent) : {};
    const updateExtras = (variant) => {
      const saving = $('[data-saving]', section);
      if (saving) {
        const amount = variant.compare_at_price > variant.price ? variant.compare_at_price - variant.price : 0;
        saving.hidden = amount === 0;
        saving.textContent = (strings.youSave || '').replace('__AMOUNT__', formatMoney(amount, moneyFormat));
      }
      const low = $('[data-low-stock]', section);
      if (low) {
        const qty = stock[variant.id];
        low.hidden = !(qty > 0);
        if (qty > 0) $('[data-low-stock-text]', low).textContent = (strings.lowStock || '').replace('__COUNT__', qty);
      }
      $$('.offer-tier input', section).forEach((input) => {
        const qty = parseInt(input.value, 10);
        const disc = parseInt(input.dataset.discount, 10) || 0;
        const unit = Math.floor((variant.price * (100 - disc)) / 100);
        const tier = input.closest('.offer-tier');
        const total = $('[data-tier-total]', tier) || $('[data-tier-price]', tier);
        if (total) total.textContent = formatMoney(unit * qty, moneyFormat);
        const unitEl = $('[data-tier-unit]', tier);
        if (unitEl) unitEl.textContent = (strings.perTee || '__PRICE__').replace('__PRICE__', formatMoney(unit, moneyFormat));
      });
      const sticky = document.querySelector('[data-sticky-atc]');
      if (sticky) {
        $('[data-sticky-price]', sticky).textContent = formatMoney(variant.price, moneyFormat);
        $('[data-sticky-variant]', sticky).textContent = variant.title === 'Default Title' ? '' : variant.title;
        $('[data-sticky-add]', sticky).disabled = !variant.available;
      }
    };

    fieldsets.forEach((fs) => fs.addEventListener('change', onChange));

    /* Initial state */
    const initial = selectedOptions();
    updateAvailability(initial);
    if (colorIndex >= 0) filterMediaByColor(initial[colorIndex]);

    initProductForm(form);
  });

  /* ------------------------------------------------------------------------
   * Add to cart (AJAX) + toast
   * ---------------------------------------------------------------------- */
  function initProductForm(form) {
    if (!form) return;

    const upload = $('[data-design-upload]', form);
    if (upload) {
      upload.addEventListener('change', () => {
        const name = upload.files && upload.files[0] ? upload.files[0].name : '';
        const drop = upload.closest('.file-drop');
        const label = $('[data-file-name]', drop);
        if (name) label.textContent = name;
        drop.classList.toggle('has-file', !!name);
      });
    }

    /* Gift box add-on: the tee and the box go into the cart in one request */
    const giftBox = $('[data-gift-box]', form);
    if (giftBox) {
      const toggle = $('[data-gift-box-toggle]', giftBox);
      const message = $('[data-gift-message]', giftBox);
      toggle.addEventListener('change', () => {
        if (!message) return;
        message.hidden = !toggle.checked;
        message.disabled = !toggle.checked;
        if (toggle.checked) message.focus();
      });
    }
    const withGiftBox = (fd, toggle) => {
      const out = new FormData();
      const item = { properties: [] };
      for (const [key, value] of fd.entries()) {
        if (key === 'id') item.id = value;
        else if (key === 'quantity') item.quantity = value;
        else if (key.startsWith('properties[')) { if (String(value).trim()) item.properties.push([key.slice(11, -1), value]); }
        else out.append(key, value);
      }
      out.append('items[0][id]', item.id);
      out.append('items[0][quantity]', item.quantity || 1);
      item.properties.forEach(([k, v]) => out.append(`items[0][properties][${k}]`, v));
      out.append('items[1][id]', toggle.value);
      out.append('items[1][quantity]', 1);
      out.append('items[1][properties][For]', toggle.dataset.giftFor || '');
      return out;
    };

    form.addEventListener('submit', async (e) => {
      const errorEl = $('[data-form-error]', form);
      if (errorEl) errorEl.hidden = true;

      /* Validate required fields manually (form uses novalidate) */
      const invalid = $$('[required]', form).find((el) => (el.type === 'file' ? !el.files.length : !el.value));
      if (invalid) {
        e.preventDefault();
        if (errorEl) {
          errorEl.textContent = invalid.closest('.field') ? `${$('.field__label', invalid.closest('.field')).textContent.replace('*', '').trim()} is required.` : strings.error;
          errorEl.hidden = false;
        }
        invalid.focus();
        return;
      }

      /* Files are uploaded with a normal form post for maximum reliability */
      const hasFile = upload && upload.files && upload.files.length;
      const giftToggle = $('[data-gift-box-toggle]', form);
      const withGift = !!(giftToggle && giftToggle.checked && !hasFile);
      if ((window.theme.cartType === 'page' && !withGift) || hasFile) return;

      e.preventDefault();
      const button = $('[data-add-to-cart]', form);
      if (button) button.classList.add('is-loading');

      try {
        await addToCart(withGift ? withGiftBox(new FormData(form), giftToggle) : new FormData(form));
      } catch (err) {
        if (errorEl) {
          errorEl.textContent = err.message || strings.error;
          errorEl.hidden = false;
        }
      } finally {
        if (button) button.classList.remove('is-loading');
      }
    });

    /* Bundle tiers set the quantity */
    const qtyInput = $('input[name="quantity"]', form);
    $$('.offer-tier input', form).forEach((radio) => {
      radio.addEventListener('change', () => {
        if (qtyInput) qtyInput.value = radio.value;
      });
    });
    if (qtyInput) {
      qtyInput.addEventListener('change', () => {
        const match = $$('.offer-tier input', form).find((r) => r.value === qtyInput.value);
        $$('.offer-tier input', form).forEach((r) => { r.checked = r === match; });
      });
    }
  }

  /* ------------------------------------------------------------------------
   * Cart drawer (Section Rendering API)
   * ---------------------------------------------------------------------- */
  const DRAWER_SECTION = 'cart-drawer';

  function drawerEl() { return document.querySelector('[data-cart-drawer]'); }

  function openDrawer() {
    const drawer = drawerEl();
    if (!drawer) { window.location.href = window.theme.routes.cart; return; }
    drawer.classList.add('is-open');
    drawer.setAttribute('aria-hidden', 'false');
    document.body.classList.add('drawer-open');
    const panel = $('.cart-drawer__panel', drawer);
    if (panel) panel.focus();
  }

  function closeDrawer() {
    const drawer = drawerEl();
    if (!drawer) return;
    drawer.classList.remove('is-open');
    drawer.setAttribute('aria-hidden', 'true');
    document.body.classList.remove('drawer-open');
  }

  function renderSections(sections, itemCount) {
    if (sections && sections[DRAWER_SECTION]) {
      const wasOpen = drawerEl() && drawerEl().classList.contains('is-open');
      const doc = new DOMParser().parseFromString(sections[DRAWER_SECTION], 'text/html');
      const fresh = doc.querySelector('[data-cart-drawer]');
      const current = drawerEl();
      if (fresh && current) {
        current.innerHTML = fresh.innerHTML;
        if (wasOpen) current.classList.add('is-open');
      }
    }
    if (typeof itemCount === 'number') {
      $$('[data-cart-count]').forEach((el) => { el.textContent = itemCount; });
      $$('[data-cart-count-bubble]').forEach((el) => { el.hidden = itemCount === 0; });
    }
  }

  async function addToCart(formData) {
    formData.append('sections', DRAWER_SECTION);
    formData.append('sections_url', window.location.pathname);
    const res = await fetch(`${window.theme.routes.cartAdd}.js`, {
      method: 'POST',
      headers: { Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
      body: formData,
    });
    const data = await res.json();
    if (!res.ok || data.status) throw new Error(data.description || data.message || strings.error);
    const cart = await (await fetch(`${window.theme.routes.cart}.js`, { headers: { Accept: 'application/json' } })).json();
    renderSections(data.sections, cart.item_count);
    if (window.theme.cartType === 'page') {
      window.location.href = window.theme.routes.cart;
    } else {
      openDrawer();
    }
    return data;
  }
  window.theme.addToCart = addToCart;

  async function changeLine(line, quantity) {
    const drawer = drawerEl();
    if (drawer) drawer.classList.add('is-loading');
    try {
      const res = await fetch(`${window.theme.routes.cartChange}.js`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({ line, quantity, sections: [DRAWER_SECTION], sections_url: window.location.pathname }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.description || strings.error);
      renderSections(data.sections, data.item_count);
    } catch (err) {
      window.alert(err.message || strings.error);
    } finally {
      const d = drawerEl();
      if (d) d.classList.remove('is-loading');
    }
  }

  document.addEventListener('click', (e) => {
    const change = e.target.closest('[data-cart-change]');
    if (change && change.closest('[data-cart-drawer]')) {
      const line = parseInt(change.closest('[data-line]').dataset.line, 10);
      changeLine(line, Math.max(0, parseInt(change.dataset.cartChange, 10)));
      return;
    }
    if (e.target.closest('[data-cart-drawer-close]')) { closeDrawer(); return; }
    const cartLink = e.target.closest('.header__icon--cart');
    if (cartLink && drawerEl() && window.theme.cartType !== 'page' && !document.body.classList.contains('template-cart')) {
      e.preventDefault();
      openDrawer();
    }
  });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeDrawer(); });

  /* Coupon codes in the cart: applied with /cart/update.js so the saving shows right away */
  const decode = (str) => { const t = document.createElement('textarea'); t.innerHTML = str; return t.value; }; // Shopify escapes ' as &#39;
  const couponText = (key, code) => decode((window.theme.strings && window.theme.strings[key]) || key).replace('__CODE__', code || '');
  function couponCodes(box) {
    const list = box && box.querySelector('[data-cart-coupon-codes]');
    return list ? list.dataset.cartCouponCodes.split(',').map((c) => c.trim()).filter(Boolean) : [];
  }
  async function setCoupons(box, codes, added) {
    const msg = box.querySelector('[data-cart-coupon-msg]');
    const show = (text, ok) => { if (!msg) return; msg.textContent = text; msg.hidden = !text; msg.classList.toggle('is-ok', !!ok); };
    box.classList.add('is-loading');
    try {
      const onPage = !box.closest('[data-cart-drawer]');
      const res = await fetch(`${window.theme.routes.cart}/update.js`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({ discount: codes.join(','), sections: onPage ? [] : [DRAWER_SECTION], sections_url: window.location.pathname }),
      });
      const cart = await res.json();
      if (!res.ok) throw new Error(cart.description || 'error');
      const entry = added && (cart.discount_codes || []).find((d) => d.code.toUpperCase() === added.toUpperCase());
      const rejected = added && (!entry || !entry.applicable);
      if (rejected && entry) {
        // keep the cart clean: drop the code Shopify could not apply
        await fetch(`${window.theme.routes.cart}/update.js`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
          body: JSON.stringify({ discount: codes.filter((c) => c.toUpperCase() !== added.toUpperCase()).join(',') }),
        });
      }
      if (onPage) {
        if (rejected) show(couponText('couponInvalid', added));
        else window.location.reload();
        return { rejected };
      }
      renderSections(rejected ? null : cart.sections, cart.item_count);
      const fresh = document.querySelector('[data-cart-drawer] [data-cart-coupon]') || box;
      const freshMsg = fresh.querySelector('[data-cart-coupon-msg]');
      if (freshMsg) {
        freshMsg.textContent = rejected ? couponText('couponInvalid', added) : added ? couponText('couponApplied', added) : '';
        freshMsg.hidden = !freshMsg.textContent;
        freshMsg.classList.toggle('is-ok', !rejected);
      }
      return { rejected };
    } catch (err) {
      show(couponText('couponError'));
      return { rejected: true, failed: true };
    } finally {
      box.classList.remove('is-loading');
    }
  }
  document.addEventListener('click', (e) => {
    const apply = e.target.closest('[data-cart-coupon-apply]');
    const remove = e.target.closest('[data-cart-coupon-remove]');
    if (!apply && !remove) return;
    const box = e.target.closest('[data-cart-coupon]');
    if (remove) {
      const code = remove.dataset.cartCouponRemove;
      // a store credit code: give the credit back first, then take it off the cart
      const back = /^CR-/i.test(code) ? creditCall(box, 'cancel', { code }).catch(() => null) : Promise.resolve();
      back.then(() => setCoupons(box, couponCodes(box).filter((c) => c.toUpperCase() !== code.toUpperCase())));
      return;
    }
    const input = box.querySelector('[data-cart-coupon-input]');
    const code = (input.value || '').trim().toUpperCase();
    const msg = box.querySelector('[data-cart-coupon-msg]');
    if (!code) { if (msg) { msg.textContent = couponText('couponEmpty'); msg.hidden = false; } input.focus(); return; }
    let codes = couponCodes(box).filter((c) => c.toUpperCase() !== code);
    // one Dojo Run reward per order: a new HF- code replaces the one already on the cart
    if (/^HF\d+-/.test(code)) codes = codes.filter((c) => !/^HF\d+-/i.test(c));
    setCoupons(box, codes.concat(code), code);
  });
  /* Store credit: "Use ₹X" turns the customer's credit into a one-time code (rewards worker) */
  function creditCall(el, action, extra) {
    const src = el.dataset.creditApi || el.dataset.api ? el.dataset : (el.closest('[data-cart-drawer], main') || document).querySelector('[data-credit-api]').dataset;
    let origin = '';
    try { origin = new URL(/^https?:\/\//i.test(src.creditApi || src.api) ? (src.creditApi || src.api) : `https://${src.creditApi || src.api}`).origin; } catch (e) { return Promise.reject(e); }
    const body = Object.assign({ customer: src.creditCustomer || src.customer, ts: src.creditTs || src.ts, sig: src.creditSig || src.sig }, extra);
    return fetch(`${origin}/credit/${action}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) })
      .then((r) => r.json());
  }
  document.addEventListener('click', async (e) => {
    const btn = e.target.closest('[data-credit-redeem]');
    if (!btn) return;
    const card = btn.closest('[data-credit-use]');
    const msg = card.querySelector('[data-credit-msg]');
    const say = (t) => { msg.textContent = t; msg.hidden = !t; };
    const container = btn.closest('[data-cart-drawer]') || btn.closest('main') || document;
    const box = container.querySelector('[data-cart-coupon]');
    btn.disabled = true;
    card.classList.add('is-loading');
    try {
      const res = await creditCall(btn, 'redeem', { amount: btn.dataset.amount });
      if (!res || !res.code) { say(couponText(res && res.error === 'no_credit' ? 'creditNone' : 'creditError')); btn.disabled = false; return; }
      const result = box ? await setCoupons(box, couponCodes(box).filter((c) => c.toUpperCase() !== res.code).concat(res.code), res.code) : { rejected: true };
      if (result && result.rejected) {
        await creditCall(btn, 'cancel', { code: res.code }).catch(() => null); // never leave credit stuck in an unused code
        // usually another code in the cart is set not to combine with other discounts
        const freshBox = container.querySelector('[data-cart-coupon]') || box;
        const others = couponCodes(freshBox).filter((c) => !/^CR-/i.test(c));
        const boxMsg = freshBox && freshBox.querySelector('[data-cart-coupon-msg]');
        if (boxMsg) { boxMsg.textContent = ''; boxMsg.hidden = true; }
        const freshCard = container.querySelector('[data-credit-use]') || card;
        const freshMsg = freshCard.querySelector('[data-credit-msg]');
        const text = others.length ? couponText('creditCombine', others.join(', ')) : couponText('creditError');
        if (freshMsg) { freshMsg.textContent = text; freshMsg.hidden = false; } else say(text);
        const freshBtn = freshCard.querySelector('[data-credit-redeem]');
        if (freshBtn) freshBtn.disabled = false;
        btn.disabled = false;
      }
    } catch (err) {
      say(couponText('creditError'));
      btn.disabled = false;
    } finally {
      card.classList.remove('is-loading');
    }
  });

  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Enter' || !e.target.matches('[data-cart-coupon-input]')) return;
    e.preventDefault(); // the cart page input sits inside the checkout form
    const btn = e.target.closest('[data-cart-coupon]').querySelector('[data-cart-coupon-apply]');
    if (btn) btn.click();
  });

  function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str == null ? '' : String(str);
    return div.innerHTML;
  }

  /* ------------------------------------------------------------------------
   * Collection sort auto-submit
   * ---------------------------------------------------------------------- */
  $$('[data-auto-submit]').forEach((select) => {
    select.addEventListener('change', () => select.form.submit());
  });

  /* ------------------------------------------------------------------------
   * Customer pages
   * ---------------------------------------------------------------------- */
  $$('[data-toggle-recover]').forEach((link) => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const recover = $('#RecoverPassword');
      const login = $('#CustomerLogin');
      const showRecover = recover.hidden;
      recover.hidden = !showRecover;
      login.hidden = showRecover;
    });
  });
  if (window.location.hash === '#recover' && $('#RecoverPassword')) {
    $('#RecoverPassword').hidden = false;
    $('#CustomerLogin').hidden = true;
  }

  $$('form[data-confirm]').forEach((form) => {
    form.addEventListener('submit', (e) => {
      if (!window.confirm(form.dataset.confirm)) e.preventDefault();
    });
  });

  $$('select[data-default]').forEach((select) => {
    if (select.dataset.default) select.value = select.dataset.default;
  });

  /* ------------------------------------------------------------------------
   * Quick add (product cards & upsells)
   * ---------------------------------------------------------------------- */
  const quickModal = $('[data-quick-add-modal]');

  function swatchColor(name) {
    const map = window.theme.swatches || {};
    return map[String(name).toLowerCase()] || String(name).toLowerCase().replace(/\s+/g, '');
  }

  function renderQuickAdd(product) {
    const body = $('[data-quick-add-body]', quickModal);
    const fmt = window.theme.moneyFormat;
    const first = product.variants.find((v) => v.available) || product.variants[0];
    const optionsHtml = product.options.map((opt, i) => {
      const isColor = /^colou?r$/i.test(opt.name);
      const values = opt.values.map((val) => {
        const id = `qa-${i}-${val.replace(/\W+/g, '-')}`;
        const checked = first.options[i] === val ? 'checked' : '';
        const label = isColor
          ? `<label for="${id}" class="swatch-label" title="${escapeHtml(val)}"><span class="swatch" style="--swatch:${escapeHtml(swatchColor(val))}"></span><span class="visually-hidden">${escapeHtml(val)}</span></label>`
          : `<label for="${id}" class="pill">${escapeHtml(val)}</label>`;
        return `<input type="radio" class="visually-hidden" id="${id}" name="qa-${i}" value="${escapeHtml(val)}" ${checked}>${label}`;
      }).join('');
      return `<fieldset class="option" data-qa-option="${i}"><legend class="option__label">${escapeHtml(opt.name)}: <span data-qa-value>${escapeHtml(first.options[i])}</span></legend><div class="option__values${isColor ? ' option__values--swatch' : ''}">${values}</div></fieldset>`;
    }).join('');
    const hasOptions = !(product.variants.length === 1 && product.variants[0].title === 'Default Title');

    body.innerHTML = `
      <div class="quick-add__grid">
        <div class="quick-add__media ratio ratio--portrait"><img data-qa-image src="${product.featured_image ? product.featured_image + (product.featured_image.includes('?') ? '&' : '?') + 'width=600' : ''}" alt=""></div>
        <div class="quick-add__info">
          <p class="quick-add__title">${escapeHtml(product.title)}</p>
          <div class="price" data-qa-price></div>
          ${hasOptions ? optionsHtml : ''}
          <button type="button" class="button button--full" data-qa-add>${escapeHtml(strings.addToCart)}</button>
          <p class="form-message form-message--error" data-qa-error hidden></p>
          <a href="${product.url}" class="link-underline">${escapeHtml(strings.viewDetails)}</a>
        </div>
      </div>`;

    const selected = () => $$('[data-qa-option]', body).map((fs) => ($('input:checked', fs) || {}).value);
    const update = () => {
      const sel = selected();
      $$('[data-qa-option]', body).forEach((fs, i) => { $('[data-qa-value]', fs).textContent = sel[i] || ''; });
      const v = product.variants.find((x) => x.options.every((o, i) => o === sel[i]));
      const btn = $('[data-qa-add]', body);
      const price = $('[data-qa-price]', body);
      if (!v) { btn.disabled = true; btn.textContent = strings.unavailable; price.innerHTML = ''; return null; }
      btn.disabled = !v.available;
      btn.textContent = v.available ? strings.addToCart : strings.soldOut;
      const sale = v.compare_at_price > v.price;
      price.className = `price${sale ? ' price--on-sale' : ''}`;
      price.innerHTML = `<span class="price__current">${formatMoney(v.price, fmt)}</span>${sale ? `<s class="price__compare">${formatMoney(v.compare_at_price, fmt)}</s>` : ''}`;
      if (v.featured_image && v.featured_image.src) {
        const src = v.featured_image.src;
        $('[data-qa-image]', body).src = src + (src.includes('?') ? '&' : '?') + 'width=600';
      }
      return v;
    };
    body.addEventListener('change', update);
    update();

    $('[data-qa-add]', body).addEventListener('click', async (e) => {
      const v = update();
      if (!v) return;
      const btn = e.currentTarget;
      btn.classList.add('is-loading');
      try {
        const fd = new FormData();
        fd.append('id', v.id);
        fd.append('quantity', 1);
        quickModal.close();
        await addToCart(fd);
      } catch (err) {
        if (!quickModal.open || quickModal.isClosing) quickModal.showModal();
        const errEl = $('[data-qa-error]', body);
        errEl.textContent = err.message || strings.error;
        errEl.hidden = false;
      } finally {
        btn.classList.remove('is-loading');
      }
    });
  }

  document.addEventListener('click', async (e) => {
    const trigger = e.target.closest('[data-quick-add]');
    if (!trigger) return;
    e.preventDefault();
    if (trigger.dataset.variantId) {
      trigger.classList.add('is-loading');
      try {
        const fd = new FormData();
        fd.append('id', trigger.dataset.variantId);
        fd.append('quantity', 1);
        await addToCart(fd);
      } catch (err) {
        window.alert(err.message || strings.error);
      } finally {
        trigger.classList.remove('is-loading');
      }
      return;
    }
    if (!quickModal || !quickModal.showModal) { window.location.href = trigger.dataset.quickAdd; return; }
    $('[data-quick-add-body]', quickModal).innerHTML = '<div class="quick-add__loading"></div>';
    quickModal.showModal();
    try {
      const res = await fetch(`${trigger.dataset.quickAdd.split('?')[0]}.js`);
      renderQuickAdd(await res.json());
    } catch (_) {
      window.location.href = trigger.dataset.quickAdd;
    }
  });

  /* ------------------------------------------------------------------------
   * Sticky add to cart
   * ---------------------------------------------------------------------- */
  const sticky = $('[data-sticky-atc]');
  const mainAdd = $('[data-product] [data-add-to-cart]');
  if (sticky && mainAdd && 'IntersectionObserver' in window) {
    const footer = $('.footer');
    let pastButton = false;
    let atFooter = false;
    const toggle = () => {
      const show = pastButton && !atFooter;
      sticky.hidden = !show;
      document.body.classList.toggle('has-sticky-atc', show);
    };
    new IntersectionObserver(([entry]) => {
      pastButton = !entry.isIntersecting && entry.boundingClientRect.top < 0;
      toggle();
    }).observe(mainAdd);
    if (footer) new IntersectionObserver(([entry]) => { atFooter = entry.isIntersecting; toggle(); }).observe(footer);
    $('[data-sticky-add]', sticky).addEventListener('click', () => {
      const form = mainAdd.closest('form');
      if (form.requestSubmit) form.requestSubmit(mainAdd); else mainAdd.click();
    });
  }

  /* ------------------------------------------------------------------------
   * Countdown timers (only to the real sale end date set in theme settings)
   * ---------------------------------------------------------------------- */
  $$('[data-countdown]').forEach((el) => {
    const end = Date.parse(el.dataset.countdown);
    if (isNaN(end)) return;
    const container = el.closest('[data-countdown-container]');
    const pad = (n) => String(n).padStart(2, '0');
    const tick = () => {
      const diff = end - Date.now();
      if (diff <= 0) {
        el.hidden = true;
        if (container) container.hidden = true;
        return false;
      }
      const s = Math.floor(diff / 1000);
      $('[data-cd-days]', el).textContent = pad(Math.floor(s / 86400));
      $('[data-cd-hours]', el).textContent = pad(Math.floor((s % 86400) / 3600));
      $('[data-cd-mins]', el).textContent = pad(Math.floor((s % 3600) / 60));
      $('[data-cd-secs]', el).textContent = pad(s % 60);
      el.hidden = false;
      if (container) container.hidden = false;
      return true;
    };
    if (tick()) {
      const timer = setInterval(() => { if (!tick()) clearInterval(timer); }, 1000);
    }
  });

  /* ------------------------------------------------------------------------
   * Copy coupon codes
   * ---------------------------------------------------------------------- */
  document.addEventListener('click', async (e) => {
    const btn = e.target.closest('[data-copy]');
    if (!btn) return;
    const code = btn.dataset.copy;
    try {
      await navigator.clipboard.writeText(code);
    } catch (_) {
      const tmp = document.createElement('textarea');
      tmp.value = code;
      document.body.appendChild(tmp);
      tmp.select();
      document.execCommand('copy');
      tmp.remove();
    }
    btn.classList.add('is-copied');
    const label = btn.matches('.coupon__copy') ? btn : null;
    const original = label ? label.textContent : '';
    if (label) label.textContent = strings.copied;
    setTimeout(() => {
      btn.classList.remove('is-copied');
      if (label) label.textContent = original;
    }, 2000);
  });

  /* ------------------------------------------------------------------------
   * Sign-up popup (shown once per 7 days, or after a successful sign-up)
   * ---------------------------------------------------------------------- */
  const popup = $('[data-popup]');
  if (popup && popup.showModal) {
    const KEY = 'theme:popup-dismissed';
    const store = {
      get() { try { return parseInt(localStorage.getItem(KEY), 10) || 0; } catch (_) { return 0; } },
      set() { try { localStorage.setItem(KEY, String(Date.now())); } catch (_) { /* ignore */ } },
    };
    const posted = window.location.search.includes('customer_posted=true') && $('[data-popup-success]', popup);
    if (posted) {
      popup.showModal();
      store.set();
    } else if (Date.now() - store.get() > 7 * 24 * 3600 * 1000) {
      const tryOpen = () => {
        // never interrupt a Dojo Run game in progress; try again a little later
        if (document.querySelector('.dojo-run.is-running')) { setTimeout(tryOpen, 15000); return; }
        if (!document.querySelector('dialog[open]') && !document.body.classList.contains('drawer-open')) popup.showModal();
      };
      setTimeout(tryOpen, (parseInt(popup.dataset.delay, 10) || 8) * 1000);
    }
    popup.addEventListener('close', () => store.set());
    $$('[data-popup-close]', popup).forEach((b) => b.addEventListener('click', () => popup.close()));
  }

  /* ------------------------------------------------------------------------
   * Delivery estimate + pincode check
   * ---------------------------------------------------------------------- */
  $$('[data-delivery]').forEach((el) => {
    const minDays = parseInt(el.dataset.min, 10) || 3;
    const maxDays = parseInt(el.dataset.max, 10) || 7;
    const cutoff = parseInt(el.dataset.cutoff, 10) || 14;
    const addBusinessDays = (date, days) => {
      const d = new Date(date);
      let added = 0;
      while (added < days) {
        d.setDate(d.getDate() + 1);
        if (d.getDay() !== 0) added += 1; // skip Sundays
      }
      return d;
    };
    const fmt = (d) => d.toLocaleDateString(undefined, { weekday: 'short', day: 'numeric', month: 'short' });
    const now = new Date();
    const start = now.getHours() >= cutoff || now.getDay() === 0 ? addBusinessDays(now, 1) : now;
    const range = (strings.deliveryBy || '__START__ – __END__')
      .replace('__START__', fmt(addBusinessDays(start, minDays)))
      .replace('__END__', fmt(addBusinessDays(start, maxDays)));
    $('[data-delivery-range]', el).textContent = range;

    const cutoffEl = $('[data-delivery-cutoff]', el);
    const countdownEl = $('[data-delivery-countdown]', el);
    const updateCutoff = () => {
      const n = new Date();
      const end = new Date(n);
      end.setHours(cutoff, 0, 0, 0);
      const diff = end - n;
      if (diff <= 0 || n.getDay() === 0) { cutoffEl.hidden = true; return; }
      const h = Math.floor(diff / 3600000);
      const m = Math.floor((diff % 3600000) / 60000);
      countdownEl.textContent = `${h}h ${m}m`;
      cutoffEl.hidden = false;
    };
    if (cutoffEl) { updateCutoff(); setInterval(updateCutoff, 30000); }

    const pinForm = $('[data-pincode]', el);
    const result = $('[data-pincode-result]', el);
    if (pinForm) {
      const input = $('input', pinForm);
      try { input.value = localStorage.getItem('theme:pincode') || ''; } catch (_) { /* ignore */ }
      const check = () => {
        const pin = input.value.trim();
        result.hidden = false;
        if (!/^[1-9][0-9]{5}$/.test(pin)) {
          result.textContent = strings.invalidPincode;
          return;
        }
        try { localStorage.setItem('theme:pincode', pin); } catch (_) { /* ignore */ }
        result.textContent = (strings.deliveryTo || '').replace('__PIN__', pin).replace('__DATES__', range);
      };
      $('[data-pincode-check]', pinForm).addEventListener('click', check);
      input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') { e.preventDefault(); check(); }
      });
    }
  });

  /* ------------------------------------------------------------------------
   * Product recommendations
   * ---------------------------------------------------------------------- */
  $$('[data-recommendations]').forEach(async (el) => {
    if (!el.dataset.url || el.children.length) return;
    try {
      const html = await (await fetch(el.dataset.url)).text();
      const fresh = new DOMParser().parseFromString(html, 'text/html').querySelector('[data-recommendations]');
      if (fresh && fresh.innerHTML.trim()) el.innerHTML = fresh.innerHTML;
    } catch (_) { /* ignore */ }
  });

  /* ------------------------------------------------------------------------
   * Recently viewed (stored in this browser only)
   * ---------------------------------------------------------------------- */
  const RV_KEY = 'theme:recently-viewed';
  const rvRead = () => { try { return JSON.parse(localStorage.getItem(RV_KEY)) || []; } catch (_) { return []; } };
  const current = $('[data-recent-product]');
  if (current) {
    try {
      const item = JSON.parse(current.textContent);
      const list = rvRead().filter((p) => p.handle !== item.handle);
      list.unshift(item);
      localStorage.setItem(RV_KEY, JSON.stringify(list.slice(0, 12)));
    } catch (_) { /* ignore */ }
  }
  $$('[data-recently-viewed]').forEach((section) => {
    const limit = parseInt(section.dataset.limit, 10) || 4;
    const items = rvRead().filter((p) => p.handle !== section.dataset.current).slice(0, limit);
    if (!items.length) return;
    const fmt = window.theme.moneyFormat;
    $('[data-recently-viewed-list]', section).innerHTML = items.map((p) => `
      <li class="product-grid__item"><div class="card">
        <a href="${escapeHtml(p.url)}" class="card__media ratio ratio--portrait">${p.image ? `<img class="card__image" src="${escapeHtml(p.image)}" alt="" loading="lazy">` : ''}</a>
        <div class="card__info">
          <h3 class="card__title"><a href="${escapeHtml(p.url)}">${escapeHtml(p.title)}</a></h3>
          <div class="price${p.compare > p.price ? ' price--on-sale' : ''}"><span class="price__current">${formatMoney(p.price, fmt)}</span>${p.compare > p.price ? `<s class="price__compare">${formatMoney(p.compare, fmt)}</s>` : ''}</div>
        </div>
      </div></li>`).join('');
    section.hidden = false;
  });
})();

/* --------------------------------------------------------------------------
 * Battle animations: scroll reveals, petals/embers, scroll progress blade
 * ------------------------------------------------------------------------ */
(() => {
  const body = document.body;
  if (!body || !body.classList.contains('has-war-fx')) return;
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  document.documentElement.classList.add('fx-on');

  // Scroll reveals with a small stagger between siblings
  const targets = document.querySelectorAll([
    'main .section__header', 'main .product-grid__item', 'main .tile', 'main .virtue', 'main .price-tile',
    'main .testimonial', 'main .print-method', 'main .offer-card', 'main .trust__item', 'main .dojo__item',
    'main .haiku-banner__media', 'main .haiku-banner__content', 'main .image-text__media', 'main .image-text__content',
    'main .faq__list', 'main .compare', 'main .dojo-run__stage', 'main .dojo-run__tiers'
  ].join(','));
  if ('IntersectionObserver' in window && targets.length) {
    const io = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        entry.target.classList.add('is-in');
        io.unobserve(entry.target);
      });
    }, { rootMargin: '0px 0px -6% 0px', threshold: 0.08 });
    targets.forEach((el) => {
      if (el.closest('.product, .cart-drawer, .quick-add, .slideshow')) return;
      const siblings = el.parentElement ? [...el.parentElement.children] : [];
      const i = Math.min(Math.max(siblings.indexOf(el), 0), 6);
      el.style.setProperty('--fx-d', `${i * 0.08}s`);
      el.classList.add('fx-reveal');
      io.observe(el);
    });
  }

  // Falling petals in the hero and haiku banner, embers in the footer
  if (body.hasAttribute('data-fx-petals')) {
    const sprinkle = (host, cls, count) => {
      if (!host || host.querySelector(`.${cls}`)) return;
      const layer = document.createElement('div');
      layer.className = cls;
      layer.setAttribute('aria-hidden', 'true');
      for (let n = 0; n < count; n++) {
        const i = document.createElement('i');
        i.style.setProperty('--x', `${Math.random() * 100}%`);
        i.style.setProperty('--d', `${7 + Math.random() * 7}s`);
        i.style.setProperty('--delay', `${-Math.random() * 12}s`);
        layer.appendChild(i);
      }
      host.appendChild(layer);
    };
    const mobile = window.innerWidth < 750;
    document.querySelectorAll('.slideshow, .haiku-banner').forEach((el) => sprinkle(el, 'fx-petals', mobile ? 8 : 16));
    document.querySelectorAll('.footer').forEach((el) => sprinkle(el, 'fx-embers', mobile ? 8 : 14));
  }

  // Scroll progress blade
  const bar = document.querySelector('.fx-scrollbar');
  if (bar) {
    let ticking = false;
    const update = () => {
      const max = document.documentElement.scrollHeight - window.innerHeight;
      bar.style.setProperty('--fx-progress', max > 0 ? (window.scrollY / max).toFixed(4) : 0);
      ticking = false;
    };
    window.addEventListener('scroll', () => { if (!ticking) { ticking = true; requestAnimationFrame(update); } }, { passive: true });
    update();
  }
})();

/* Track order form: opens the courier tracking page */
/* Track order: order number + phone/email -> every shipment with courier, status and link (rewards server);
   or a tracking number -> courier recognised from the number itself */
(() => {
  const root = document.querySelector('[data-track]');
  if (!root) return;
  let S = {};
  try { S = JSON.parse(root.querySelector('[data-track-strings]').textContent); } catch (e) { S = {}; }
  const t = (k, x) => String(S[k] || '').replace('__X__', x == null ? '' : x);
  const esc = (v) => String(v == null ? '' : v).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const day = (d) => (d ? new Date(d).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' }) : '');
  const result = root.querySelector('[data-track-result]');
  const orderForm = root.querySelector('[data-track-order-form]');
  const awbForm = root.querySelector('[data-track-awb-form]');
  const sw = root.querySelector('[data-track-switch]');

  const COURIERS = {
    delhivery: { name: 'Delhivery', url: root.dataset.urlDelhivery },
    dtdc: { name: 'DTDC', url: root.dataset.urlDtdc }
  };
  const courierFromName = (name) => (/delhivery/i.test(name) ? 'delhivery' : /dtdc/i.test(name) ? 'dtdc' : '');
  const courierFromAwb = (awb) => (/^\d{12,14}$/.test(awb) ? 'delhivery' : /^[a-z]\d{8,11}$/i.test(awb) ? 'dtdc' : '');
  const linkFor = (key, awb) => ((key && COURIERS[key].url) || root.dataset.urlOther || '').replace('__ID__', encodeURIComponent(awb));

  // tracking-number form: recognise the courier as they type
  const awbInput = root.querySelector('[data-track-awb]');
  const detected = root.querySelector('[data-track-detected]');
  const showDetected = () => {
    const v = awbInput.value.trim();
    const key = courierFromAwb(v);
    detected.textContent = v.length < 6 ? '' : key ? t('detected', COURIERS[key].name) : t('detected_other');
  };
  awbInput.addEventListener('input', showDetected);
  awbForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const v = awbInput.value.trim().replace(/\s+/g, '');
    if (!v) { awbInput.focus(); return; }
    window.open(linkFor(courierFromAwb(v), v), '_blank', 'noopener');
  });

  if (sw) {
    sw.addEventListener('click', () => {
      const toAwb = awbForm.hidden;
      awbForm.hidden = !toAwb;
      orderForm.hidden = toAwb;
      result.hidden = true;
      sw.textContent = toAwb ? t('have_order') : t('have_awb');
      sw.setAttribute('aria-expanded', String(toAwb));
      (toAwb ? awbInput : orderForm.querySelector('input')).focus();
    });
  }
  if (!orderForm) return;

  const STEP = { DELIVERED: 4, OUT_FOR_DELIVERY: 3, ATTEMPTED_DELIVERY: 3, IN_TRANSIT: 2, PICKED_UP: 2 };
  const steps = ['step_ordered', 'step_shipped', 'step_transit', 'step_out', 'step_delivered'];
  const msg = orderForm.querySelector('[data-track-msg]');
  const say = (text) => { msg.textContent = text; msg.hidden = !text; };

  function shipmentCard(s, i, count) {
    const key = courierFromName(s.courier) || courierFromAwb(s.awb);
    const name = s.courier || (key ? COURIERS[key].name : '');
    const url = s.url || (s.awb ? linkFor(key, s.awb) : '');
    const at = STEP[s.status] != null ? STEP[s.status] : 1;
    const when = s.deliveredAt ? t('delivered_on', day(s.deliveredAt)) : s.eta ? t('eta', day(s.eta)) : '';
    return `<div class="track-result__ship">
      ${count > 1 ? `<p class="track-result__label">${esc(t('shipment', i + 1))}</p>` : ''}
      <div class="track-result__courier">
        <span class="track-result__courier-name">${esc(name || '—')}</span>
        ${s.awb ? `<span class="track-result__awb">${esc(t('awb'))} <b>${esc(s.awb)}</b></span>` : ''}
      </div>
      <ol class="track-steps" role="list">
        ${steps.map((k, n) => `<li class="${n < at || at === 4 ? 'is-done' : n === at ? 'is-now' : ''}"><span></span><small>${esc(t(k))}</small></li>`).join('')}
      </ol>
      ${when ? `<p class="track-result__when">${esc(when)}</p>` : ''}
      ${url ? `<a class="button button--full track-result__go" href="${esc(url)}" target="_blank" rel="noopener">${esc(name ? t('track_on', name) : t('track_live'))} ↗</a>` : ''}
    </div>`;
  }

  orderForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const order = orderForm.order.value.trim();
    const contact = orderForm.contact.value.trim();
    if (!order || !contact) { say(t('need_both')); return; }
    say('');
    const btn = orderForm.querySelector('button[type="submit"]');
    btn.disabled = true;
    root.classList.add('is-loading');
    try {
      let origin = root.dataset.api.trim();
      origin = new URL(/^https?:\/\//i.test(origin) ? origin : `https://${origin}`).origin;
      const res = await fetch(`${origin}/track`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ order, contact })
      }).then((r) => r.json());
      if (!res || res.error) {
        say(t(res && res.error === 'not_found' ? 'not_found' : res && res.error === 'too_many' ? 'too_many' : 'error'));
        result.hidden = true;
        return;
      }
      let body = `<div class="track-result__head"><b>${esc(t('order', res.order))}</b><span>${esc(t('placed', day(res.placedAt)))}</span></div>`;
      if (res.cancelled) body += `<p class="track-result__note">${esc(t('cancelled'))}</p>`;
      else if (!res.shipments.length) {
        body += `<ol class="track-steps" role="list">${steps.map((k, n) => `<li class="${n === 0 ? 'is-now' : ''}"><span></span><small>${esc(t(k))}</small></li>`).join('')}</ol>`;
        body += `<p class="track-result__note">${esc(t('packing'))}</p>`;
      } else body += res.shipments.map((s, i) => shipmentCard(s, i, res.shipments.length)).join('');
      result.innerHTML = body;
      result.hidden = false;
      result.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    } catch (err) {
      say(t('error'));
    } finally {
      btn.disabled = false;
      root.classList.remove('is-loading');
    }
  });
})();

/* Dojo Run reward reminder: follows the shopper across the store once they win */
(() => {
  const KEY = 'hf_dojo_reward';
  const read = () => { try { return JSON.parse(localStorage.getItem(KEY)); } catch (e) { return null; } };
  const escapeHtml = (v) => String(v == null ? '' : v).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const closed = () => { try { return sessionStorage.getItem('hf_reward_pill') === 'closed'; } catch (e) { return false; } };
  const render = () => {
    const r = read();
    let pill = document.querySelector('.reward-pill');
    const expired = r && (r.expiresAt ? new Date(r.expiresAt).getTime() < Date.now() : Date.now() - (r.at || 0) > 14 * 864e5);
    if (!r || !r.code || closed() || expired) { if (pill) pill.remove(); return; }
    if (!pill) {
      pill = document.createElement('div');
      pill.className = 'reward-pill';
      pill.setAttribute('role', 'status');
      document.body.appendChild(pill);
    }
    const root = (window.Shopify && window.Shopify.routes && window.Shopify.routes.root) || '/';
    const href = `${root}discount/${encodeURIComponent(r.code)}?redirect=${encodeURIComponent(root + 'collections/all')}`;
    pill.innerHTML = `<span class="reward-pill__seal" aria-hidden="true">勝</span>
      <span class="reward-pill__text"><b>${escapeHtml(r.label || `${r.percent}%`)} OFF unlocked</b><small>Code ${escapeHtml(r.code)} · added to your cart</small></span>
      <a class="reward-pill__cta" href="${escapeHtml(href)}">Shop</a>
      <button type="button" class="reward-pill__close" aria-label="Close">×</button>`;
    pill.querySelector('.reward-pill__close').addEventListener('click', () => {
      try { sessionStorage.setItem('hf_reward_pill', 'closed'); } catch (e) { /* ignore */ }
      pill.remove();
    });
  };
  document.addEventListener('dojo:reward', render);
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', render); else render();
})();

/* Japanese text: tap shows the English meaning (hover does it on desktop via CSS) */
(() => {
  let timer;
  const closeAll = (except) => document.querySelectorAll('[data-en].is-en-open').forEach((el) => { if (el !== except) el.classList.remove('is-en-open'); });
  document.addEventListener('click', (e) => {
    const el = e.target.closest('[data-en]');
    if (!el) { closeAll(); return; }
    if (window.matchMedia('(hover: hover)').matches) return;
    // first tap on a seal inside a product link shows the meaning instead of navigating
    if (!el.classList.contains('is-en-open') && el.closest('a')) e.preventDefault();
    closeAll(el);
    el.classList.toggle('is-en-open');
    clearTimeout(timer);
    timer = setTimeout(() => el.classList.remove('is-en-open'), 3000);
  });
})();

/* Eye button: show/hide English meanings everywhere, remembered across pages */
(() => {
  const html = document.documentElement;
  const buttons = document.querySelectorAll('[data-translate-toggle]');
  if (!buttons.length) return;
  const sync = () => buttons.forEach((b) => b.setAttribute('aria-pressed', html.classList.contains('show-en') ? 'true' : 'false'));
  sync();
  buttons.forEach((b) => b.addEventListener('click', () => {
    const on = html.classList.toggle('show-en');
    try { localStorage.setItem('hf_show_en', on ? '1' : '0'); } catch (e) { /* ignore */ }
    b.classList.remove('is-hint');
    sync();
  }));
  // first visit on a phone: pulse the button a few times so shoppers notice it
  try {
    if (!localStorage.getItem('hf_show_en') && !localStorage.getItem('hf_en_hint') && window.matchMedia('(hover: none)').matches) {
      localStorage.setItem('hf_en_hint', '1');
      setTimeout(() => buttons.forEach((b) => b.classList.add('is-hint')), 2200);
    }
  } catch (e) { /* ignore */ }
})();
